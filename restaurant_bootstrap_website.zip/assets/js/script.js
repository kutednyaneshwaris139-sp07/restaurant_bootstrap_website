
document.addEventListener("DOMContentLoaded", () => {
  const navbar = document.querySelector(".navbar");
  const updateNav = () => navbar && navbar.classList.toggle("scrolled", window.scrollY > 20);
  updateNav();
  window.addEventListener("scroll", updateNav);

  // Current year
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());

  // Menu filtering
  const filterButtons = document.querySelectorAll("[data-filter]");
  const menuItems = document.querySelectorAll(".menu-item");
  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const filter = btn.dataset.filter;
      menuItems.forEach(item => {
        item.classList.toggle("d-none", filter !== "all" && item.dataset.category !== filter);
      });
    });
  });

  // Demo forms
  document.querySelectorAll(".demo-form").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      if (!form.checkValidity()) {
        form.classList.add("was-validated");
        return;
      }
      const toast = document.getElementById("successToast");
      if (toast && window.bootstrap) bootstrap.Toast.getOrCreateInstance(toast).show();
      form.reset();
      form.classList.remove("was-validated");
    });
  });

  // Set minimum reservation date to today
  const dateInput = document.querySelector("#reservationDate");
  if (dateInput) {
    const d = new Date();
    const local = new Date(d.getTime() - d.getTimezoneOffset()*60000).toISOString().split("T")[0];
    dateInput.min = local;
  }
});
