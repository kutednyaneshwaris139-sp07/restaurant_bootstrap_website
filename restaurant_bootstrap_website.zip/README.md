# La Tavola — Bootstrap Restaurant Website

Ready-made responsive restaurant website built with Bootstrap 5.

## Pages
- index.html — Home
- about.html — About
- menu.html — Menu with category filtering
- reservation.html — Reservation form (demo)
- contact.html — Contact form (demo)

## Run
Open `index.html` in a browser, or use VS Code Live Server.

## Customize
1. Change restaurant name, address, phone and email in the HTML files.
2. Replace files in `assets/images/` with your own photos.
3. Edit colors and typography in `assets/css/style.css`.
4. Connect the reservation/contact forms to your backend, email service, or booking provider.
5. Replace the map placeholder with a Google Maps iframe.

Bootstrap and Bootstrap Icons are loaded from their CDNs.
